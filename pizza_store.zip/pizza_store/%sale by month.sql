select pizza_category, sum(total_price), sum(total_price) * 100 / (select sum(total_price) from pizza_sales where month(order_date)=1) AS percentage_pizza_sale
from pizza_sales
where month(order_date)=1
group by pizza_category 
#apply where caluse in both sub query and query
