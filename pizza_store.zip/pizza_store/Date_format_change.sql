-- View the current data
SELECT order_date FROM pizza_sales;

-- Update the date format
UPDATE pizza_sales
SET order_date = STR_TO_DATE(order_date, '%d-%m-%Y')
WHERE STR_TO_DATE(order_date, '%d-%m-%Y') IS NOT NULL;

-- View the updated data
SELECT order_date FROM pizza_sales;
