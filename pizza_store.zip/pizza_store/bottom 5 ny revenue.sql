select  pizza_name, sum(total_price) AS total_revenue FROM pizza_sales
group by pizza_name
order by total_revenue ASC
limit 5;
