select monthname(order_date) as month_name, COUNT(DISTINCT order_id) as total_orders
from pizza_sales
group by  monthname(order_date)
order by total_orders DESC 
