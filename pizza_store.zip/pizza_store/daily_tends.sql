select dayname(order_date) as order_day, count(distinct order_id) AS total_orders
from pizza_sales
group by dayname(order_date)
#group by with categorical data always