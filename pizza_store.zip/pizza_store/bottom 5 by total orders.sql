select  pizza_name, count(DISTINCT order_id) AS total_orders FROM pizza_sales
group by pizza_name
order by total_orders ASC
limit 5;
