SELECT cast(sum(quantity) as DECIMAL (10,2) ) / 
cast(count(DISTINCT order_id)as DECIMAL (10,2)) as average_pizza_per_order FROM pizza_sales
#cast used to find decimal upto 10 place` out of which 2 are useful