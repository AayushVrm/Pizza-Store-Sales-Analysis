# SELECT * FROM pizza_sales
Select sum(total_price) / count(distinct order_id) as average_order_value from pizza_sales