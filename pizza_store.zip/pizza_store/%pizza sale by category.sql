select pizza_category, sum(total_price), sum(total_price) * 100 / (select sum(total_price) from pizza_sales) AS percentage_pizza_sale
from pizza_sales
group by pizza_category 
# where month(order_date)=1  use this querry to know  how much sales % is done in january(1) only