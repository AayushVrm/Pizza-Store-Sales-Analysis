select pizza_size,cast( sum(total_price) as DECIMAL (10,2))as total_sales, CAST(sum(total_price) * 100 / (select sum(total_price) from pizza_sales where quarter(order_date)=1) as DECIMAL (10,2)) AS percentage_pizza_sale
from pizza_sales
where quarter(order_date)=1 #for looking up in 1st quarter only
group by pizza_size
order by percentage_pizza_sale desc
  
#apply where caluse in both sub query and query  
 