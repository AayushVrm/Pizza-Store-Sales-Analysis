select  pizza_name, sum(quantity) AS total_quantity FROM pizza_sales
group by pizza_name
order by total_quantity DESC
limit 5;
